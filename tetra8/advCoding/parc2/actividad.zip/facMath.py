import math

num=int(input("Dame un numero: "))

print "El factorial es: ",math.factorial(num)
