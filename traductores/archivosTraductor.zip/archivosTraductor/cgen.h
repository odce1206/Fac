#ifndef _CGEN_H_
#define _CGEN_H_
void codeGen(TreeNode * syntaxTree, char * codefile);
#endif
